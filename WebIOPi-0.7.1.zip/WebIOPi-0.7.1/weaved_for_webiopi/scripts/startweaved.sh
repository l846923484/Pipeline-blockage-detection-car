#!/bin/bash

# Add Weaved service starts for reboot
